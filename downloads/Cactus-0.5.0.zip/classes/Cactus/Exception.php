<?php

namespace Cactus;

/**
 * Exceptions for the Cactus library.
 *
 * @package    Cactus
 * @author     Dave Widmer <dave@davewidmer.net>
 */
class Exception extends \Exception{}

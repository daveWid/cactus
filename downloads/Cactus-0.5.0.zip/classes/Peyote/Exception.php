<?php

namespace Peyote;

/**
 * A Peyote Exception class
 *
 * @package    Peyote
 * @author     Dave Widmer <dave@davewidmer.net>
 */
class Exception extends \Exception{}
